<article class="post">
    <header class="post__header">
         <h1 class="post__title">Page not found</h1>
    </header>
    <section class="post__content">
         <p>The page you are looking for might have been removed, had its address changed, or be temporarily unavailable.</p>
    </section>
</article>
