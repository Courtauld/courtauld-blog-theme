<section class="meta">
   Posted on <a href="<?php the_permalink(); ?>"><time datetime="<?php the_time('Y-m-d H:i'); ?>"><?php the_time('F j, Y'); ?></time></a> by <?php the_author_posts_link(); ?>
</section>
